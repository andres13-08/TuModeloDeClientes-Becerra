class Cliente:
    # Atributo de clase (opcional)
    plataforma = "Estrenar Vivienda Shop"

    def __init__(self, nombre, email, presupuesto, es_inversionista):
        # Atributos de instancia (Mínimo 4)
        self.nombre = nombre
        self.email = email
        self.presupuesto = presupuesto
        self.es_inversionista = es_inversionista
        self.carrito = []

    def __str__(self):
        # Método magic para identificar al objeto
        return f"Cliente: {self.nombre} - Contacto: {self.email}"

    # Métodos Propios (Fuera de los magic methods)
    def agregar_al_carrito(self, producto):
        self.carrito.append(producto)
        print(f"✅ {producto} ha sido agregado al carrito de {self.nombre}.")

    def realizar_compra(self):
        if len(self.carrito) > 0:
            print(f"🛍️ Procesando compra de {len(self.carrito)} artículos para {self.nombre}...")
            self.carrito = []
        else:
            print(f"❌ El carrito de {self.nombre} está vacío.")